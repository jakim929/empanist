Utility.dsk = function() {
  return {
    'data-schema-key': this.atts['data-schema-key']
  };
};

