Template.afInputText_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
})
