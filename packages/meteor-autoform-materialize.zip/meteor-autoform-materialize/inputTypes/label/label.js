Template.afLabel_materialize.helpers({
  atts: function() {
    var labelAtts;
    labelAtts = this.afFieldLabelAtts;
    return labelAtts;
  }
});
