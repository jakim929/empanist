Template.afInputEmail_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
});
