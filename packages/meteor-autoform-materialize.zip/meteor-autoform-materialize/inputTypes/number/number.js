Template.afInputNumber_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
});
