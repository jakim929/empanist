Template.afInputDate_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
});
