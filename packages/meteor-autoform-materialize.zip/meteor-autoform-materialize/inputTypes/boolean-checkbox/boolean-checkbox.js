Template.afCheckbox_materialize.helpers({
 atts: Utility.attsToggleInvalidClass
});
