Template.afInputMonth_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
});
