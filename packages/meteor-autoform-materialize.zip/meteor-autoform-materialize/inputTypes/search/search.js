Template.afInputSearch_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
});
