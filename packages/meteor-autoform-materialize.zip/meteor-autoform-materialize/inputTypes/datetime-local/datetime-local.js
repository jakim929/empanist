Template.afInputDateTimeLocal_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
});
