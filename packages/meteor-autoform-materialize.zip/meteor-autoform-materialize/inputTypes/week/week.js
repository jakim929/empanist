Template.afInputWeek_materialize.helpers({
  atts: Utility.attsToggleInvalidClass
});
